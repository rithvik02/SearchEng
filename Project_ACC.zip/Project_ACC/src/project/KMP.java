package project;

public class KMP {
	static void computeLongestPrefixSuffixArray(String pattern, int M, int longestPrefixSuffix[])
    {
		longestPrefixSuffix[0]=0;
        //initialize the variables and index 0 of LPS 
        int j=1,size = 0;

        //process the pattern
        while (j < M) {
            if (pattern.charAt(j) == pattern.charAt(size)) {
                size=size+1;
                longestPrefixSuffix[j] = size;
                j=j+1;
            }
            else 
            {
                if (size != 0) {
                    size = longestPrefixSuffix[size - 1];
                }
                else 
                {
                	longestPrefixSuffix[j] = size;
                    j=j+1;
                }
            }
        }
    }
	static int search(String pattern, String text)
    {
		int n=text.length(),m = pattern.length(),count=0;
        int p=0,q = 0;
        // initialize the LongestPrefixSuffix array with size m 
        int longestPrefixSuffix[] = new int[m];
         
        // computing the LongestPrefixSuffix array 
        computeLongestPrefixSuffixArray(pattern, m, longestPrefixSuffix);
        while ((n - p) >= (m - q)) {
        	//if current character in pattern matches with text character, then
            if (pattern.charAt(q) == text.charAt(p)) {
                q=q+1;
                p=p+1;
            }
            //if entire pattern is processed then we found a match
            if (q == m) {
                System.out.println("Found pattern "
                                + "at index " + (p - q));
                count=count+1;
                q = longestPrefixSuffix[q - 1];
               
            }
 
         // if its not both the case
            else if (p < n && pattern.charAt(q) != text.charAt(p)) {
                if (q != 0)
                    q = longestPrefixSuffix[q - 1];
                else
                    p = p + 1;
            }
        }
        return count;
    }
}
