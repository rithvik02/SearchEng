package project;
import java.io.FileWriter;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;


public class Dict {

	
	public static void createDictionary() {
		TreeMap<String,String> map ;
		File my_dir;
		String[] data;
		my_dir= new File("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\TEXT");
		data = my_dir.list();
		String x;
		// initialize a tree map
		map= new TreeMap<>();
		for (String temp:data)
		{
			// iterate over the files
			 x= temp.substring(temp.lastIndexOf(".")+1);
			if (x.equals("txt"))
			{
				// if a file has txt extension then
				try {
					// create a dictionary
					dictionary("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\TEXT\\" + "/"+ temp,map);
					// create a file writer object
					FileWriter object = new FileWriter("dictionary.txt"); 
					// iterate over the map values
					for(String str: map.values()) 
					  object.write(str + System.lineSeparator());
					// close the file writer object
					object.close();
				} catch (Exception e) {
					// handle the exception here if any
					e.printStackTrace();
				}
			}
		}
	}
	public static TreeMap<String,String> dictionary(String path,TreeMap<String,String> map) throws Exception{
		File newFile;
		String list[];
		String line,x,y;
		// create a new file
		newFile= new File(path);
		@SuppressWarnings("resource")
		// create a buffer object to read a file
		BufferedReader bufferReaderObject= new BufferedReader(new FileReader(newFile));
		int j;
		// read line by line from file
		while((line = bufferReaderObject.readLine()) != null) {
		     x = line.replaceAll("[^a-zA-Z]", "-");
		    y=x.toLowerCase();
		     // split string with a separator
				list=y.split("-");
				int n=list.length;
				for( j=0;j<n;j++)
					map.put(list[j],list[j]);
		}
		return map;
	}
}