package project;

import java.io.BufferedReader;
import java.io.BufferedWriter;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.FileWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;


public class WebCrawler 
{
	private static final int capacity = 10;
	// to define the capacity of how many links to be retrieved
	int total = 0;
	// to track of how many links retrieved so far
	private HashSet<String> urls=new HashSet<String>();
	// to store list of http links fetched
	ArrayList<String> list = new ArrayList<String>();

	public void savehttpLink(final String x, final String y) 
	{
		{
			try 
			{
				// try to write code in exception handling blocks as we are dealing with file operations
				String z=x + ".html",temp;
				// create html extension file
				URL newLink = new URL(y);
				//create buffer reader object to read from files 
				BufferedReader bufferReaderObject = new BufferedReader(new InputStreamReader(newLink.openStream()));
				//create buffer writer object to write into files 				
				BufferedWriter bufferWriterObject = new BufferedWriter(new FileWriter("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\HTML\\" + z));
		
				// here, temp is used to store each line that was read from file
				while((temp = bufferReaderObject.readLine()) != null) bufferWriterObject.write(temp);
				// to avoid memory leak, close reader and writer object
				bufferReaderObject.close();
				bufferWriterObject.close();
		
			}
			
	
			catch(MalformedURLException mue) 
			{
				// handle the exception here. so, the program wont break
				System.out.println("Malformed URL Exception raised");
			}
			catch(IOException ie) 
			{
				// handle the exception here. so, the program wont break
				System.out.println("IOException raised");
			}
		}
		
	}
	
	
	public void retreive_All_Urls(String httpLink)
	{
		if((urls.contains(httpLink)==false))
		{
			// if urls array doesn't contain the current link then fetch it
			try {
				// try to write code in exception handling blocks as we are dealing with file operations
					if(urls.add(httpLink)) 
					{
						int j;
						String x,y;
						// add current link to list of urls
						list.add(httpLink);
						j = list.indexOf(httpLink);
						// convert it to string as it can be used as unique filename
					    x = Integer.toString(j);
						y = httpLink;
						savehttpLink(x, y);
						System.out.println(httpLink);
						
					}
					// connect to the html page
					Document doc = Jsoup.connect(httpLink).get();
					// use Jsoup library to efficiently access html elements
					Elements pages = doc.select("a[href]");
					// iterate over the links
					for(Element page : pages) 
					{
						// check the total capacity and don't retrieve links if capacity exceeded
						if(total != capacity)
						{
							total=total+1;
							//make a recursive call to fetch another link as capacity haven't exceeded
							retreive_All_Urls(page.attr("abs:href"));
					
						}
					}
				}
				catch(IOException e) 
				{
					// handle the exception here. so, the program wont break
					System.err.println("For '"+httpLink+ "': "+e.getMessage());
				}
		}
	}

   public static void main(String[] asd) {}
		
	
	public void retreiveAllUrls(String url) {
		retreive_All_Urls(url);
	}

	
}