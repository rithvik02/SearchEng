package project;
import java.util.*;
class Node
{
	String searchWord;
	ArrayList<String> result;
	Node left;
	Node right;
	Node(String searchWord,ArrayList<String> result)
	{
		this.searchWord=searchWord;
		this.result=result;
		this.left=null;
		this.right=null;
	}
}
public class Cache {
    public static HashMap<String,Node> map=new HashMap<String,Node>();
    public static int capacity=2;
    public static Node start,end;
    public static boolean isHit(String searchWord)
    {
    	if(map.containsKey(searchWord))
    	{
    	  Node node = map.get(searchWord);
		  remove(node);
		  addAtHead(node);
		  long startTime=System.nanoTime();
		  System.out.println("Cache Hit !! Retreving from Cache Memory");
		  System.out.println("Sites in ranking order:");
		  for(String file:node.result)	System.out.println(file);
		  long endTime=System.nanoTime();
		  System.out.println("CPU Time noted was: "+(endTime-startTime)+" nanoseconds");
		  return true;
        }
     return false;
    }
    public static void put(String searchWord,ArrayList<String> result) 
    {
		
			Node newnode = new Node(searchWord,result);
			if (map.size() ==capacity) 
			{
			    map.remove(end.searchWord);
				remove(end);				
				addAtHead(newnode);

			} 
			else {
				addAtHead(newnode);
			}

			map.put(searchWord, newnode);
	}
    public static void remove(Node node) {

		if (node.left != null) node.left.right = node.right;
		
		//attaching next node to the previous node
		else 	start = node.right;
		
         // if linked list has only one element
		if (node.right != null) node.right.left = node.left;
		 
		//attaching previous node to the next node as it was double linked list
		else end = node.left;
	}
    public static void addAtHead(Node node) {
		node.right = start;
		//make the new node as head of linked list
		node.left = null;
		// add at the beginning of the double linked list
		if (start != null)
			start.left = node;
		start = node;
		//if linked list has only one element then start and end pointers point to the same
		if (end == null)
			end = start;
	}
    
}
