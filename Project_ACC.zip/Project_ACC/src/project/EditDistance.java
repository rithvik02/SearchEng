package project;

public class EditDistance {

	public static int minDistance(String string1, String string2) {
        int p,q;
        int[][] dp;
        p= string1.length();
        // find lengths of strings
        q = string2.length();
        int j,k;
        dp = new int[p + 1][q + 1];
        // initialize first row
        for(j= 0; j <= p; j++)
            dp[j][0] = j;
        // initialize first column
        for(j = 1; j <= q; j++)
            dp[0][j] = j;
        // fill the 2d DP table 
        int x,y,z;
        for( j = 0; j < p; j++) {
            for( k = 0; k< q; k++) {
            	// if corresponding characters match
                if(string1.charAt(j) == string2.charAt(k))
                    dp[j + 1][k + 1] = dp[j][k];
             // if corresponding characters doesn't match
                else {
                    x = dp[j][k];
                    y = dp[j][k + 1];
                    z = dp[j + 1][k];
                    // formulae to update table
                    dp[j + 1][k + 1] = x < y ? (x < z ? x : z) : (y < z ? y : z);
                    // increment the cell
                    dp[j + 1][k + 1]++;
                }
            }
        }
        return dp[p][q];
    }
}