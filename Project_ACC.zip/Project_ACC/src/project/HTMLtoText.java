package project;

import java.io.File;
import org.jsoup.*;
import java.io.IOException;
import java.io.PrintWriter;



public class HTMLtoText{
   
	public static void generateTextFiles() throws IOException {
		File[] files;
		File directory;
		// read from html directory
		directory= new File("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\HTML\\");
		 files= directory.listFiles();
         int n=files.length,j=0;
		 while(j<n)
		 {
			 // if it was a file
			if (files[j].isFile()) 
				createSingleFile(files[j].getName());
			j=j+1;
		}
		System.out.println("\n HTML Files are converted into Text files.");
	}
	public static void createSingleFile(String path) throws IOException {

		File newFile;
		String temp,x,pattern="[.][^.]+$";
		// read from the given path
		newFile= new File("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\HTML\\" + path);
		org.jsoup.nodes.Document file = Jsoup.parse(newFile, "UTF-8");
		temp = file.text();
        // use regular expressions to get file name without extensions
		x= path.replaceFirst(pattern, "");
		// create a writer object
		PrintWriter object = new PrintWriter("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\TEXT\\" + x + ".txt");
		// perform write operation 
		object.println(temp);
		// close the writer
		object.close();
	}
	
}
