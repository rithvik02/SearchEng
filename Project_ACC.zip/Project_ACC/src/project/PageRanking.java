package project;
import java.util.*;

public class PageRanking {
	public static void rankFiles(Hashtable<String, Integer> map, int fileCount,String keyword) {
		// create an array list to store these map items
		ArrayList<Map.Entry<?, Integer>> arrayList ;
		ArrayList<String> result;
		arrayList= new ArrayList<>(map.entrySet());
		// sort the array list in ascending order as per comparator
		Collections.sort(arrayList, new comp());
		// reverse the array list to find top large 5
		Collections.reverse(arrayList);
		// if received map isn't empty then 
		if (fileCount >0) {
			// rank the sites as per keyword frequency
			System.out.println("\nSites in ranking order:");
			 result=new ArrayList<String>();
			 int i=0;
			 while(i<5)
			 {
				 String text="(" + i + ") " + arrayList.get(i) + " times ";
				result.add(text);
				// print the sites in ranking order to the console
				System.out.println(text);
				i=i+1;
				
			}
			Cache.put(keyword,result);
			System.out.println("Cache Miss !!");
			System.out.println("Cache memory updated");
		} 
		
	}

}
class comp implements Comparator<Map.Entry<?, Integer>>{
	@Override
    public int compare(Map.Entry<?, Integer> entry1,Map.Entry<?, Integer> entry2) {
		if(entry1.getValue() < entry2.getValue()) return -1;
		if(entry1.getValue() == entry2.getValue()) return 0;
		else return 1;
    }
}