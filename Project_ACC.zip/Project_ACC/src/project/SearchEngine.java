package project;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.File;
import java.util.*;

public class SearchEngine {
			
	public static void main(String[] args) throws Exception {
		System.out.println("Web Search Engine developed by \nSaikiran Gogineni");
		System.out.println("Anusha");
		System.out.println("Harsh");
		System.out.println();
		
		try (Scanner scannerObject = new Scanner(System.in)) {
			        Hashtable<String, Integer> map = new Hashtable<String, Integer>();
			        String enteredLink;
			        //create object of search engine
			        SearchEngine webSearchEngine;
			        //create object of web crawler
			        WebCrawler webCrawlerObject;
					System.out.println("Hi,Type the Link to Crawl and fetch sites:");
					//initialize the crawler object
					webCrawlerObject = new WebCrawler();
					//initialize the engine object
					webSearchEngine = new SearchEngine();
					enteredLink = scannerObject.nextLine();
					webCrawlerObject.retreiveAllUrls(enteredLink);
					HTMLtoText.generateTextFiles();
					System.out.println("----------------------");
					
							
					
					String choice;
					while(true) {	
						System.out.println("Enter the Keyword to search ");
						String keyword;
						keyword= scannerObject.nextLine();
						long startTime,endTime;
						if(Cache.isHit(keyword))
						{
							System.out.println("\n  If you Like to continue, press yes ");
							choice = scannerObject.nextLine();
							if(choice.equals("yes")) continue;
							else
							{
								System.out.println(" Bye !!");
								scannerObject.close();
								return;
							}
						}
						else {
						startTime=System.nanoTime();
						int count = 0, fileCount = 0; 
						try {
							File directory = new File("C:\\Users\\sai\\eclipse-workspaceO\\Project_ACC\\TEXT\\");
							File[] files = directory.listFiles();
							int n=files.length,j=0;
							while(j < n) {
								count = webSearchEngine.find(files[j], keyword);
								map.put(files[j].getName(), count); 
								if (count != 0) 
									fileCount=fileCount+1;
								
								map.put(files[j].getName(), count); 
								j=j+1;
							}
							System.out.println("\n "+ keyword + "is present in " + fileCount+ "files");
							if (fileCount == 0) {
								// creating a dictionary
								Dict.createDictionary();
								System.out.println("word not found");
								webSearchEngine.recommend(keyword);
							}
							else
							{
							endTime=System.nanoTime();
							// rank the files present in map to fetch top 5
							PageRanking.rankFiles(map,fileCount,keyword);
							// print the time consumed
							System.out.println("CPU Time noted was: "+(endTime-startTime)+" nanoseconds");
							}
							System.out.println("\n If you Like to continue, press yes ");
							choice = scannerObject.nextLine();
							if(choice.equals("yes")) continue;
							else
							{
								System.out.println(" Bye !!");
								scannerObject.close();
								return;
							}
							}
						catch (Exception e) {
							System.out.println("Exception:" + e);
						}
						}
					}	
		}
		
	}
	
	
	public int find(File file, String keyword) throws IOException {
		String Text = "";
		char pattern[] = keyword.toCharArray();
		try {
			String temp;
			// create a buffer reader object to read from file
			BufferedReader bufferReader = new BufferedReader(new FileReader(file));
			while ((temp =bufferReader.readLine()) != null) 
			Text = Text + temp;
			
			bufferReader.close();
		} 
		catch (NullPointerException e) {
			e.printStackTrace();
		}
		char text[] = Text.toCharArray();
		int patternCount;
		patternCount = KMP.search(new String(pattern), new String(text));
		if (patternCount == 0) return patternCount;
		else
		{
			System.out.println("\n "+file.getName()+" contains the keyword");
		    return patternCount;
		}
	}
	
	public static void recommend(String keyword) throws IOException {
		// create a new file to store list of words
		File newfile ;
		newfile= new File("dictionary.txt");
		// create a buffer reader object to read from the above file
		try (BufferedReader bufferReaderObject = new BufferedReader(new FileReader(newfile))) {
			ArrayList<String> list = new ArrayList<>();
			String temp=null;
			while((temp= bufferReaderObject.readLine())!=null)
				list.add(temp);
			
			
			int n=list.size(),editDistance,md=1000, smd=1000;
			String word;
			int index=0;
			for(int j = 0; j<n;j++){
				word=list.get(j);
				editDistance = EditDistance.minDistance(word, keyword);
				if(editDistance<smd) {
					if(editDistance<md) {
						md=editDistance;
						index=j;
					}
				
				}
			}
			System.out.println(" Entered Keyword is not present, Instead search for "+list.get(index));
		}	
	}
	
}
